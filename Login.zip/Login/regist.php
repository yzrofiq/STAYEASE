<?php
include 'koneksi.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $mobilePhone = $_POST['mobilePhone'];
    $email = $_POST['email'];
    $birthDate = $_POST['birthDate'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // Validate passwords
    if ($password !== $confirmPassword) {
        $message = "Passwords do not match.";
    } else {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO user (nama_depan, nama_belakang, no_hp, email, tgl_lahir, password) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $firstName, $lastName, $mobilePhone, $email, $birthDate, $hashedPassword);

        // Execute the statement
        if ($stmt->execute()) {
            $message = "New record created successfully";
            echo "<script>setTimeout(function(){ window.location.href = 'Verification.html'; }, 1000);</script>";
        } else {
            $message = "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }

    // Close the connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>StayEase Hotels</title>
  <link rel="stylesheet" href="Regist.css">
</head>
<body>
  <header>
    <nav>
        <img src="Logo.png" alt="Logo">
        <ul>
          <li><button class="login-button" id="loginBtn">LOGIN</button></li>
          <li><button class="signup-button">SIGN UP</button></li>
      </ul>          
    </nav>
  </header>
 
  <div class="container">
      <h2>Activate Your Account</h2>
      <?php
      if ($message) {
          echo "<p>$message</p>";
      }
      ?>
      <form action="regist.php" method="post">
          <label for="Profil Information">Profil Information</label>
          <input type="text" id="firstName" name="firstName" placeholder="First Name" required>

          <input type="text" id="lastName" name="lastName" placeholder="Last Name" required>

          <input type="tel" id="mobilePhone" name="mobilePhone" placeholder="Mobile Phone" required>

          <input type="email" id="email" name="email" placeholder="Email" required>
          <label for="Birth Date (MM-DD-YY)">Birth Date (MM-DD-YY)</label>
          <input type="date" id="birthDate" name="birthDate" required>

          <label for="Password">Password</label>
          <input type="password" id="password" name="password" placeholder="Create Password" required 
                 pattern="(?=.*[a-zA-Z])(?=.*[0-9!$#%]).{8,}" 
                 title="At least 8 characters long, case sensitive, can contain !$#%, no spaces, not the same as previous password or login">

          <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm Password" required
                 pattern="(?=.*[a-zA-Z])(?=.*[0-9!$#%]).{8,}" 
                 title="At least 8 characters long, case sensitive, can contain !$#%, no spaces, not the same as previous password or login">
          <div class="detail-item">
              <img src="Warning.svg" alt="Phone">
              <p>At least 8 characters long, case sensitive, can contain !$#%, no spaces, not the same as previous password or login </p>
          </div>
          <form action="verification.html">
        <input type="submit" value="SIGN UP">
    </form>
      </form>
  </div>
</body>
</html>
